﻿# The script of the game goes in this file.

image laufey idle = "images/laufey_idle.png"
image educativa idle = "images/edu_idle.png"

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define e = Character("Laufey", who_color="#B45CFF", ctc=continue_arrow, ctc_position="fixed", callback=laufey_dialogue_sound)
define n = Character("Educativa", kind=_narrator, color="#00BB31", ctc=continue_arrow, ctc_position="fixed", callback=dialogue_advance_sound)

define music_albums = {
    "Everything I Know About Love (2022)": {
        "cover": "images/album_1.png",
        "info": [
            "Lançado em 14 de outubro de 2022, Everything I Know About Love foi o primeiro álbum de estúdio de Laufey.",
            "O álbum fala sobre os sentimentos intensos de Laufey ao crescer, o amor, a confusão e relacionamentos passados e futuros, ou a ausência deles.",
            "Com elementos de jazz, Laufey transforma sentimentos e experiências cotidianas em magia.",
        ],
        "tracks": [
            ("Fragile", "audio/album 1/1.Fragile.mp3"),
            ("Beautiful Stranger", "audio/album 1/2.Beautiful Stranger.mp3"),
            ("Valentine", "audio/album 1/3.Valentine.mp3"),
            ("Above The Chinese Restaurant", "audio/album 1/4.Above The Chinese Restaurant.mp3"),
            ("Dear Soulmate", "audio/album 1/5.Dear Soulmate.mp3"),
            ("What Love Will Do to You", "audio/album 1/6.What Love Will Do to You.mp3"),
            ("I've Never Been In Love Before", "audio/album 1/7.I_ve Never Been In Love Before.mp3"),
            ("Just Like Chet", "audio/album 1/8.Just Like Chet.mp3"),
            ("Everything I Know About Love", "audio/album 1/9.Everything I Know About Love.mp3"),
            ("Falling Behind", "audio/album 1/10.Falling Behind.mp3"),
            ("Hi", "audio/album 1/11.Hi.mp3"),
            ("Dance With You Tonight", "audio/album 1/12.Dance With You Tonight.mp3"),
            ("Night Light", "audio/album 1/13.Night Light.mp3"),
            ("Slow Down", "audio/album 1/14.Slow Down.mp3"),
            ("Lucky for Me", "audio/album 1/15.Lucky for Me.mp3"),
            ("Questions For The Universe", "audio/album 1/16.Questions For The Universe.mp3"),
        ],
    },
    "Bewitched (2023)": {
        "cover": "images/album_2.png",
        "info": [
            "Bewitched é o segundo álbum de estúdio de Laufey, lançado em 8 de setembro de 2023.",
            "Laufey o descreve como um álbum sobre o amor, seja por um amigo, por um parceiro ou pela vida.",
            "Musicalmente, o disco reúne baladas de jazz pop e foi aclamado pela crítica.",
            "Nesse álbum, as influências da música brasileira ficam ainda mais evidentes. Um exemplo é o sucesso From The Start, cuja instrumentalização remete diretamente à bossa nova.",
            "O álbum venceu Melhor Álbum Vocal Pop Tradicional no 66º Grammy Awards.",
        ],
        "tracks": [
            ("Dreamer", "audio/album 2/1.Dreamer.mp3"),
            ("Second Best", "audio/album 2/2.Second Best.mp3"),
            ("Haunted", "audio/album 2/3.Haunted.mp3"),
            ("Must Be Love", "audio/album 2/4.Must Be Love.mp3"),
            ("While You Were Sleeping", "audio/album 2/5.While You Were Sleeping.mp3"),
            ("Lovesick", "audio/album 2/6.Lovesick.mp3"),
            ("California and Me", "audio/album 2/7.California and Me.mp3"),
            ("Nocturne (Interlude)", "audio/album 2/8.Nocturne (Interlude).mp3"),
            ("Promise", "audio/album 2/9.Promise.mp3"),
            ("From The Start", "audio/album 2/10.From The Start.mp3"),
            ("Misty", "audio/album 2/11.Misty.mp3"),
            ("Serendipity", "audio/album 2/12.Serendipity.mp3"),
            ("Letter To My 13 Year Old Self", "audio/album 2/13.Letter To My 13 Year Old Self.mp3"),
            ("Bewitched", "audio/album 2/14.Bewitched.mp3"),
            ("Bored", "audio/album 2/15.Bored.mp3"),
            ("Trouble", "audio/album 2/16.Trouble.mp3"),
            ("It Could Happen To You", "audio/album 2/17.It Could Happen To You.mp3"),
            ("Goddess", "audio/album 2/18.Goddess.mp3"),
        ],
    },
    "A Matter of Time (2025)": {
        "cover": "images/album_3.png",
        "info": [
            "A Matter of Time é o terceiro álbum de estúdio de Laufey, lançado em 22 de agosto de 2025.",
            "Aclamado pela crítica, venceu Melhor Álbum Vocal Pop Tradicional no 68º Grammy Awards.",
            "O álbum explora um lado mais vulnerável e emocional, abordando términos de amizades, receios sobre o amor e introspecção pessoal.",
        ],
        "tracks": [
            ("Clockwork", "audio/album 3/1.Clockwork.mp3"),
            ("Lover Girl", "audio/album 3/2.Lover Girl.mp3"),
            ("Snow White", "audio/album 3/3.Snow White.mp3"),
            ("Castle in Hollywood", "audio/album 3/4.Castle in Hollywood.mp3"),
            ("Carousel", "audio/album 3/5.Carousel.mp3"),
            ("Silver Lining", "audio/album 3/6.Silver Lining.mp3"),
            ("Too Little, Too Late", "audio/album 3/7.Too Little_ Too Late.mp3"),
            ("Cuckoo Ballet (Interlude)", "audio/album 3/8.Cuckoo Ballet (Interlude).mp3"),
            ("Forget-Me-Not", "audio/album 3/9.Forget-Me-Not.mp3"),
            ("Tough Luck", "audio/album 3/10.Tough Luck.mp3"),
            ("A Cautionary Tale", "audio/album 3/11.A Cautionary Tale.mp3"),
            ("Mr. Eclectic", "audio/album 3/12.Mr. Eclectic.mp3"),
            ("Clean Air", "audio/album 3/13.Clean Air.mp3"),
            ("Sabotage", "audio/album 3/14.Sabotage.mp3"),
            ("Seems Like Old Times", "audio/album 3/15.Seems Like Old Times.mp3"),
            ("Madwoman", "audio/album 3/16.Madwoman.mp3"),
            ("How I Get", "audio/album 3/17.How I Get.mp3"),
            ("I Wait, I Wait, I Wait", "audio/album 3/18.I Wait_ I Wait_ I Wait.mp3"),
            ("I'll Forget About You (In Time)", "audio/album 3/19.I_ll Forget About You (In Time).mp3"),
        ],
    },
}

default music_album = "Everything I Know About Love (2022)"
default music_track = None
default hovered_album = None
default flashing_album = None

init python:
    def format_player_name(name):
        particles = {"da", "de", "do", "das", "dos", "e"}
        words = name.split()
        formatted = []

        for index, word in enumerate(words):
            lowercase_word = word.lower()
            if index > 0 and lowercase_word in particles:
                formatted.append(lowercase_word)
            else:
                formatted.append(lowercase_word[:1].upper() + lowercase_word[1:])

        return " ".join(formatted)

# The game starts here.

label start:
    scene bg2
    show educativa idle
    n "Olá! Bem-vindo a parte interativa da nossa apresentação!"
    n "Aqui, você poderá interagir com a personagem Laufey, que irá te apresentar um pouco mais do conteúdo do nosso trabalho."
    hide educativa
    scene bg3

    e "Para começar, qual seu nome?"
    $ player_name = renpy.input("Digite seu nome:")
    $ play_ui_sound("SYSTEM_2-_co_op_up_b_.ogg")
    $ player_name = player_name.strip()
    if not player_name:
        $ player_name = "Visitante"
    else:
        $ player_name = format_player_name(player_name)

    # This shows a character sprite. A placeholder is used, but you can
    # replace it by adding a file named "eileen happy.png" to the images
    # directory.

    show laufey idle

    # These display lines of dialogue.

    e "É um prazer te conhecer, [player_name]!"

    e "Na verdade, é bom eu me apresentar direito."
    e "Você sabe quem eu sou?"

    menu:
        "Sim, eu sei quem você é.":
            e "Que bom! Então podemos continuar nossa conversa."

        "Não, ainda não sei.":
            e "Tudo bem! Meu nome é Laufey.{w=0.5} Sou cantora, compositora e instrumentista islandesa, conhecida por misturar jazz, música clássica e pop em minhas canções."
            e "Minha música é inspirada nos grandes clássicos, mas também fala sobre sentimentos e experiências da vida moderna."

        "Nem quero saber...":
            e "Oh, me desculpe..."
            return

    e "Você gostaria de ouvir algumas das músicas que eu compus?"

    menu:
        "Sim, eu adoraria ouvir.":
            e "Que ótimo! Vou tocar algo para você."
            call music_player
            call music_options

        "Não, obrigado.":
            e "Tudo bem,{w=0.5} talvez outra hora..."
            call music_options

    # This ends the game.

    return

label music_player:
    scene bg4
    call music_player_loop
    show laufey idle
    return

label music_player_loop:
    while True:
        $ hovered_album = None
        $ flashing_album = None
        call screen album_select

        if _return != "album_selected":
            return

        call album_info(music_album)
        call screen track_select(music_album)

        if _return != "albums":
            return

label album_info(album_name):
    show screen album_info_cover(album_name)
    n "Você escolheu o álbum [album_name]."

    $ info_index = 0
    while info_index < len(music_albums[album_name]["info"]):
        $ info_line = music_albums[album_name]["info"][info_index]
        n "[info_line]"
        $ info_index += 1

    hide screen album_info_cover
    return

label music_options:
    scene bg3
    show laufey idle
    e "O que você gostaria de fazer agora?"

    menu:
        "Escutar as músicas":
            call music_player
            jump music_options

        "Voltar à conversa":
            $ play_ui_sound("UI_Cancel.wav")
            scene bg1
            show laufey idle
            e "Claro! Vamos continuar nossa conversa."
